#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan, sin, cos, e, ceil, floor
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
from pprint import pprint as pp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tf
from PIL import Image
import matplotlib.pyplot as plt






class noise_class():
    def __init__(self):
        rospy.init_node('make_noise')
        self.cmd=Twist()
        self.noisev=np.random.normal(0, 0.01, 30*60)
        self.noisew=np.random.normal(0, np.sqrt(2)*pi/180, 30*60)
        self.i=0
    def cmdvel_callback(self, scan):
        self.cmd=scan


    def run(self):

        self.sub= rospy.Subscriber('/robot0/cmd_vel_dummy',Twist, self.cmdvel_callback)
        pub = rospy.Publisher('/robot0/cmd_vel', Twist,queue_size=10)

        r=rospy.Rate(30)

        try:
            while not rospy.is_shutdown():
                self.cmd.linear.x+=self.noisev[self.i]
                self.cmd.angular.z+=self.noisew[self.i]
                self.i=(self.i+1)%1800
                pub.publish(self.cmd)
                r.sleep()
        except rospy.ROSInterruptException:                        
            pass                                            


if __name__ == '__main__':         
    noise = noise_class()                                                             
    try:
        noise.run()
    except rospy.ROSInterruptException:
        pass
