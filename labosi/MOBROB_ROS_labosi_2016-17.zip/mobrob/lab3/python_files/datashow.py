#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan, sin, cos, e
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
from pprint import pprint as pp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tf
from PIL import Image


mjereni_x=np.load("mjereni_x.npy")
mjereni_y=np.load("mjereni_y.npy")
stvarni_x=np.load("stvarni_x.npy")
stvarni_y=np.load("stvarni_y.npy")
estimirani_x=np.load("estimirani_x.npy")
estimirani_y=np.load("estimirani_y.npy")
plt.plot(mjereni_x[30:],mjereni_y[30:], label="zasumljeni podaci")
plt.plot(stvarni_x[30:],stvarni_y[30:], label="pravi podaci")
plt.plot(estimirani_x[30:], estimirani_y[30:], label="korigirani podaci")
plt.xlabel('x [m]')
plt.ylabel('y [m]')
plt.legend(loc='best')
plt.show()


