#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan, sin, cos, e, ceil, floor
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
from pprint import pprint as pp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tf
from PIL import Image
import matplotlib.pyplot as plt


class noise_class():
    def __init__(self):
        rospy.init_node('map_node')
        self.resolution=10
        self.sonar_coordinates=[ [10, 0],   [10, 5],  [10, 10], 
                                 [5, 10],   [0, 10],  [-5, 10],  [-10, 10],
                                 [-10, 5],  [-10, 0], [-10, -5], [-10, -10],                
                                 [-5, -10], [0, -10], [5, -10],  [10, -10],
                                 [10, -5]]
        self.sonar_thetas=[]
        for i in range(9):
            self.sonar_thetas.append(i*pi/8)                                                
        for i in range(7):
            self.sonar_thetas.append(-(7-i)*pi/8) 
        self.sonardata=np.zeros(16)
        self.cmdv=0
        self.cmdw=0
        self.flag=0
        self.niter=0
        self.roll=0
        self.pitch=0
        self.yaw=0
        self.x=0
        self.y=0
        self.P=np.eye(3)
        self.theta=0
        self.i=0
        self.map_help=np.load("third_lab_matrix.npy")
        self.map=np.zeros((150,150))
        for i in range(150):
            for j in range(150):
                self.map[i][j]=self.map_help[j][i]
        self.xsr=np.array([850, 700, 0])
        self.yaw1=[]
        self.x1=[]
        self.y1=[]
        self.xcorr=[850]
        self.ycorr=[700]   
        self.x2=[850]
        self.y2=[700]
        self.yaw2=[0]

    def sonar0_callback(self, scan):
        self.sonardata[0]=scan.range*100

    def sonar1_callback(self, scan):
        self.sonardata[1]=scan.range*100

    def sonar2_callback(self, scan):
        self.sonardata[2]=scan.range*100

    def sonar3_callback(self, scan):
        self.sonardata[3]=scan.range*100
  
    def sonar4_callback(self, scan):
        self.sonardata[4]=scan.range*100

    def sonar5_callback(self, scan):
        self.sonardata[5]=scan.range*100

    def sonar6_callback(self, scan):
        self.sonardata[6]=scan.range*100

    def sonar7_callback(self, scan):
        self.sonardata[7]=scan.range*100

    def sonar8_callback(self, scan):
        self.sonardata[8]=scan.range*100

    def sonar9_callback(self, scan):
        self.sonardata[9]=scan.range*100

    def sonar10_callback(self, scan):
        self.sonardata[10]=scan.range*100

    def sonar11_callback(self, scan):
        self.sonardata[11]=scan.range*100

    def sonar12_callback(self, scan):
        self.sonardata[12]=scan.range*100

    def sonar13_callback(self, scan):
        self.sonardata[13]=scan.range*100

    def sonar14_callback(self, scan):
        self.sonardata[14]=scan.range*100

    def sonar15_callback(self, scan):
        self.sonardata[15]=scan.range*100

    def odometry_callback(self, scan):
        quaternion = (
            scan.pose.pose.orientation.x,
            scan.pose.pose.orientation.y,
            scan.pose.pose.orientation.z,
            scan.pose.pose.orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        self.roll = euler[0]
        self.pitch = euler[1]
        self.yaw = euler[2]
        self.x=scan.pose.pose.position.x*100
        self.y=scan.pose.pose.position.y*100


    def cmdvel_callback(self, scan):
        self.cmdv=scan.linear.x*100
        self.cmdw=scan.angular.z

    def sonarpredict(self, x, y, theta):
        measure_matrix=np.zeros((16,3))
        resolution=10
        for i in range(16):
            sonarTheta = self.sonar_thetas[i] + theta
            measure_matrix[i][1]=x
            measure_matrix[i][2]=y
            xCell = ceil( measure_matrix[i][1]/resolution)      
            yCell = ceil( measure_matrix[i][2]/resolution)      
            cc=0
            while (xCell < 150) and (yCell < 150) and (0 <= xCell) and (0 <= yCell):  
                if self.map[xCell][yCell]:
                    cc+=1
                else:
                    cc=0
                if cc>2:
                    break

                measure_matrix[i][0] = measure_matrix[i][0] + (resolution/2)           
                measure_matrix[i][1] = measure_matrix[i][1]  + (resolution / 2) * cos(sonarTheta)
                measure_matrix[i][2] = measure_matrix[i][2]  + (resolution / 2) * sin(sonarTheta)
                xCell = ceil( measure_matrix[i][1]/resolution)      
                yCell = ceil( measure_matrix[i][2]/resolution)  

            if measure_matrix[i][0] > np.sqrt(self.sonar_coordinates[i][0]**2+self.sonar_coordinates[i][1]**2):
                measure_matrix[i][0] = measure_matrix[i][0] - np.sqrt(self.sonar_coordinates[i][0]**2+self.sonar_coordinates[i][1]**2)

        return measure_matrix


    def correct(self):
        xminus=np.array([self.xsr[0]+self.cmdv/30*cos(self.xsr[2]+self.cmdw/30), 
                         self.xsr[1]+self.cmdv/30*sin(self.xsr[2]+self.cmdw/30), 
                         self.xsr[2]+self.cmdw/30])

        A= np.array([[1, 0, -self.cmdv/30*sin(self.xsr[2]+self.cmdw/30)],
                     [0, 1,  self.cmdv/30*cos(self.xsr[2]+self.cmdw/30)],
                     [0, 0, 1]])

        W= np.array([[-self.cmdv/30*sin(self.xsr[2]+self.cmdw/30), cos(self.xsr[2]+self.cmdw/30)],
                     [ self.cmdv/30*cos(self.xsr[2]+self.cmdw/30), sin(self.xsr[2]+self.cmdw/30)],
                     [1, 0]])   


        w=np.array([1, 2*(pi*self.cmdw/(30*180))**2])
        xkplusjedan=xminus+np.dot(A, np.array([self.x2[-1]-self.xsr[0], self.y2[-1]-self.xsr[1], self.yaw2[-1]-self.xsr[2]]))
        Q=np.array([[0.2*(pi*self.cmdw/(30*180))**2, 0], [0, 1]])              
        Pminus=np.dot(np.dot(A,self.P), A.T)+ np.dot(np.dot(W,Q),W.T)
        measure_matrix=self.sonarpredict(xkplusjedan[0], xkplusjedan[1], xkplusjedan[2])

        H=[]
        V=[]
        yminus=[]
        ykplusjedan=[]
        for i in range(16):
            if abs(measure_matrix[i][0]-self.sonardata[i])<80:
                a=xminus[0]-measure_matrix[i][1]
                b=xminus[1]-measure_matrix[i][2]
                if np.sqrt(a**2+b**2):
                    addition=[a/np.sqrt(a**2+b**2), b/np.sqrt(a**2+b**2), 0]
                    H.append(addition)
                    yminus.append(np.sqrt(a**2+b**2))
                    ykplusjedan.append(self.sonardata[i])
        if H:
            H=np.array(H)
            V=np.eye(np.shape(H)[0])
            yminus=np.array(yminus)
            ykplusjedan=np.array(ykplusjedan)
            R=np.eye(np.shape(H)[0])

            S=np.dot(np.dot(H,Pminus), H.T)+V*100
            if np.linalg.det(S):
                K=np.dot(np.dot(Pminus,H.T),np.linalg.inv(S))
                self.P=Pminus-np.dot(np.dot(K,S),K.T)
                self.xsr=xminus+np.dot(K,(ykplusjedan-yminus))
            else:
                self.xsr=xminus
        else:
            self.xsr=xkplusjedan
        print "est:", self.xsr
        print "mje:", [self.x2[-1], self.y2[-1], self.yaw2[-1]]
        print "sta:", [self.x, self.y, self.theta]


    def save_me(self):
        np.save('mjereni_x', self.x2)
        np.save('mjereni_y', self.y2)
        np.save('stvarni_x', self.x1)
        np.save('stvarni_y', self.y1)
        np.save('estimirani_x', self.xcorr)
        np.save('estimirani_y', self.ycorr)


    def draw_me(self):
        self.save_me()
        plt.plot(self.x2[30:],self.y2[30:], label="zasumljeni podaci")
        plt.plot(self.x1[30:], self.y1[30:], label="pravi podaci")
        plt.plot(self.xcorr[30:], self.ycorr[30:], label="korigirani podaci")
        plt.xlabel('x [m]')
        plt.ylabel('y [m]')
        plt.show()


    def do_noise(self):
        self.theta=self.yaw
        self.x1.append(self.x)
        self.y1.append(self.y)
        self.yaw1.append(self.yaw)
        self.yaw2.append(self.yaw2[-1]+self.cmdw/30)
        self.x2.append((self.cmdv/30)*cos(self.yaw2[-1])+self.x2[-1])
        self.y2.append((self.cmdv/30)*sin(self.yaw2[-1])+self.y2[-1])

        self.i=(self.i+1)%1800
        if len(self.x2)==30*100:
           self.draw_me()

        self.correct()
        self.xcorr.append(self.xsr[0])
        self.ycorr.append(self.xsr[1])


    def run(self):
        self.sub= rospy.Subscriber('/robot0/sonar_0',Range, self.sonar0_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_1',Range, self.sonar1_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_2',Range, self.sonar2_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_3',Range, self.sonar3_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_4',Range, self.sonar4_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_5',Range, self.sonar5_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_6',Range, self.sonar6_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_7',Range, self.sonar7_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_8',Range, self.sonar8_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_9',Range, self.sonar9_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_10',Range, self.sonar10_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_11',Range, self.sonar11_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_12',Range, self.sonar12_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_13',Range, self.sonar13_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_14',Range, self.sonar14_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_15',Range, self.sonar15_callback)
        self.sub= rospy.Subscriber('/robot0/odom',Odometry, self.odometry_callback)
        self.sub= rospy.Subscriber('/robot0/cmd_vel_dummy',Twist, self.cmdvel_callback)
        r=rospy.Rate(30)
        cntr=0

        try:
            while not rospy.is_shutdown():
                if cntr<30:
                    cntr+=1
                else:
                    self.do_noise()
                r.sleep()
        except rospy.ROSInterruptException:                        
            pass                                            


if __name__ == '__main__':         
    noise = noise_class()                                                             
    try:
        noise.run()
    except rospy.ROSInterruptException:
        pass
