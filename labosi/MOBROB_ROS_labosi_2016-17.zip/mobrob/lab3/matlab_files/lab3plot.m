load stvarni.mat
xs=x;
ys=y;
load estimirani
ye=y;
xe=x;
load mjereni
xm=x;
ym=y;
plot(xm,ym, 'b')
hold on
plot(xe,ye, 'r--')
hold on
plot(xs,ys, 'g')
legend('Mjerena putanja','Estimirana putanja','Stvarna putanja' )
title('Trajektorije robota')
figure
plot(1:2999, ((xe-xs).^2+(ye-ys).^2).^0.5)
hold on
plot(1:2999, ((xm(1:end-1)-xs).^2+(ym(1:end-1)-ys).^2).^0.5)
title('Greska pozicije u vremenu')
legend('Greska estimacije', 'Greska mjerenja')
sum_est=1:2999;
sum_mea=sum_est;
sum_est(1)=((xe(1)-xs(1))^2+(ye(1)-ys(1))^2)^0.5;
sum_mea(1)=((xm(1)-xs(1))^2+(ym(1)-ys(1))^2)^0.5;
for i=2:2999
    sum_est(i)=sum_est(i-1)+((xe(i)-xs(i))^2+(ye(i)-ys(i))^2)^0.5;
    sum_mea(i)=sum_mea(i-1)+((xm(i)-xs(i))^2+(ym(i)-ys(i))^2)^0.5;
end
figure
plot(1:2999,sum_est)
hold on
plot(1:2999,sum_mea)
legend('Ukupna greska estimacije', 'Ukupna greska mjerenja')
title('Akumulirana greska pozicije')
