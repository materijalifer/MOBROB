#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan, sin, cos, e
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
from pprint import pprint as pp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tf
from PIL import Image

map_width=1500
map_height=1500
resolution=10
hY=150
hX=150
scale=10
plot_matrix=np.zeros((hY,hX))
matrix_larger=np.zeros((hY*scale,hX*scale))
loaded_matrix=np.load("matrix.npy")
for j in range(hY):
    for k in range(hX):
        plot_matrix[j][k]=loaded_matrix[149-j][k]         
        for l in range(scale):
            for m in range(scale):
                matrix_larger[j*scale+l][k*scale+m]= plot_matrix[j][k] 
plt.gray()
plt.imsave('map_final', plot_matrix)
plt.imsave('map_final_larger', matrix_larger)



