#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
import pprint
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


#parametri

sonarNum = 16
Rmax=130             # maksimalni domet sonara
rov = 100            # radijus vidljivosti sonara
th3db = 0.5          # kut pola sirine zrake
pE = 0.4             # donja granica vjerojatnosti nezauzetosti
pO = 0.6             # gornja granica vjerojatnosti zauzetosti
gridcellB = 2        # velicina grida je 2 piksela
deltark = 10          # podrucje u kojem mjerenje sonara poprima srednju vrijednost

#parametri grupe 1

R1 = 1
R2 = 1.005
lambda_param = 1.005


# Set up grid and test data
nx, ny = 1000, 1000
x = range(nx)
y = range(ny)
data = np.random.random((nx, ny))
d=[]
f=[]
for x_item1 in x:
    x_item=x_item1/10
    e=[]
    for y_item1 in y:
        y_item=y_item1/10
        theta= atan2((x_item-49),(y_item-9))

        if abs(theta)>th3db:
            alpha=0
        else: 
            alpha=1-(theta/th3db)**2

        r=75 
        rho=np.sqrt((x_item-49)**2+(y_item-9)**2)        
        deltarho=1-0.5*(1+tanh(2*(rho-rov)))


        if rho<(r-2*deltark):
            p=0.5+(pE-0.5)*alpha*deltarho
            f.append(1)
        elif rho>(r-2*deltark) and rho<(r-deltark):
            p=0.5+(pE-0.5)*alpha*deltarho*(1-(2+(rho-r)/deltark)**2)
            f.append(2)
        elif rho>(r-deltark) and rho<(r+deltark):
            p=0.5+(pO-0.5)*alpha*deltarho*(1-(rho-r)**2/deltark**2)
            f.append(3)
        else:
            p=0.5
            f.append(4)
        e.append(p)


    d.append(e)

#print(f)



#hf = plt.figure()
#ha = hf.add_subplot(111, projection='3d')
#X, Y = np.meshgrid(x, y)
#print np.shape(d), np.shape(X), np.shape(Y)
plt.gray()
plt.imsave('prob.png', np.asarray(d))
#ha.plot_surface(X, Y, d,cmap="coolwarm")

plt.show()






 
#if __name__ == '__main__':    
     
#    cons = cons_class()                                                             
#    try:
#        cons.run()
#    except rospy.ROSInterruptException:
#        pass
