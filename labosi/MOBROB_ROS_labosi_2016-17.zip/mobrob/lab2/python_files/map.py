#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan, sin, cos, e
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
from pprint import pprint as pp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tf
from PIL import Image

map_width=1500
map_height=1500
resolution=10





class map_class():
    def __init__(self):
        rospy.init_node('map_node')
        self.flag=0
        self.niter=0
        self.roll=0
        self.pitch=0
        self.yaw=0
        self.x=0
        self.y=0
        self.hX=map_width/resolution
        self.hY=map_height/resolution
        self.out_matrix=np.zeros((self.hY,self.hX))
        print self.hY, self.hX
        for i in range(self.hY):
            for j in range(self.hX):
                self.out_matrix[i][j]=0.5

        self.sonarNum = 16
        self.Rmax=130             # maksimalni domet sonara
        self.rov = 100            # radijus vidljivosti sonara
        self.th3db = 0.5          # kut pola sirine zrake
        self.pE = 0.4             # donja granica vjerojatnosti nezauzetosti
        self.pO = 0.6             # gornja granica vjerojatnosti zauzetosti
        self.gridcellB = 2        # velicina grida je 2 piksela
        self.deltark = 10          # podrucje u kojem mjerenje sonara poprima srednju vrijednost
        self.sonardata=np.zeros(16)
        self.sonar_coordinates=[ [10, 0],   [10, 5],  [10, 10], 
                                 [5, 10],   [0, 10],  [-5, 10],  [-10, 10],
                                 [-10, 5],  [-10, 0], [-10, -5], [-10, -10],                
                                 [-5, -10], [0, -10], [5, -10],  [10, -10],
                                 [10, -5]]
        self.sonar_thetas=[]
        for i in range(9):
            self.sonar_thetas.append(i*pi/8)                                                
        for i in range(7):
            self.sonar_thetas.append(-(7-i)*pi/8) 









    def sonar0_callback(self, scan):
        self.sonardata[0]=scan.range

    def sonar1_callback(self, scan):
        self.sonardata[1]=scan.range

    def sonar2_callback(self, scan):
        self.sonardata[2]=scan.range

    def sonar3_callback(self, scan):
        self.sonardata[3]=scan.range 
  
    def sonar4_callback(self, scan):
        self.sonardata[4]=scan.range

    def sonar5_callback(self, scan):
        self.sonardata[5]=scan.range

    def sonar6_callback(self, scan):
        self.sonardata[6]=scan.range

    def sonar7_callback(self, scan):
        self.sonardata[7]=scan.range

    def sonar8_callback(self, scan):
        self.sonardata[8]=scan.range

    def sonar9_callback(self, scan):
        self.sonardata[9]=scan.range

    def sonar10_callback(self, scan):
        self.sonardata[10]=scan.range

    def sonar11_callback(self, scan):
        self.sonardata[11]=scan.range

    def sonar12_callback(self, scan):
        self.sonardata[12]=scan.range

    def sonar13_callback(self, scan):
        self.sonardata[13]=scan.range

    def sonar14_callback(self, scan):
        self.sonardata[14]=scan.range

    def sonar15_callback(self, scan):
        self.sonardata[15]=scan.range

    def odometry_callback(self, scan):
        quaternion = (
            scan.pose.pose.orientation.x,
            scan.pose.pose.orientation.y,
            scan.pose.pose.orientation.z,
            scan.pose.pose.orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        self.roll = euler[0]
        self.pitch = euler[1]
        self.yaw = euler[2]
        self.x=scan.pose.pose.position.x
        self.y=scan.pose.pose.position.y

    def draw_map(self):
        plot_matrix=np.zeros((self.hY,self.hX))
        for j in range(self.hY):
           for k in range(self.hX):       
               plot_matrix[j][k]=256/(1+e**(-self.out_matrix[j][k]))
        plt.gray()
        plt.imsave('map.png', plot_matrix)
        #plt.imshow(plot_matrix)
        print 1
        np.save('matrix', plot_matrix)
        #hf = plt.figure()
        #ha = hf.add_subplot(111, projection='3d')
        #X, Y = np.meshgrid(range(self.hY),range(self.hX))
        #ha.plot_surface(X, Y, plot_matrix,cmap="gray")

        #plt.show()








    def do_mapping(self):
        #print self.x, self.y
        if self.x>14.5 and self.y>14 and not self.flag:
            self.flag=1
            self.draw_map()
        for i in range(16):
            if self.sonardata[i]<3:
                self.probability(i)

    

 
    def probability(self, i):
        r=self.sonardata[i]*100+np.sqrt(self.sonar_coordinates[i][0]**2+self.sonar_coordinates[i][1]**2) 
        for j in range(self.hY):
            for k in range(self.hX):
                theta1= atan2(resolution*(j+0.5)-self.y*100,resolution*(k+0.5)-self.x*100)
                theta = atan2(sin(theta1-self.sonar_thetas[i]-self.yaw), cos(theta1-self.sonar_thetas[i]-self.yaw))
                #print self.x, self.y, j, k, resolution*(j+0.5)-self.x, resolution*(k+0.5)-self.y,theta1, self.sonar_thetas[i]+self.yaw, theta
                if abs(theta)>self.th3db:
                    continue
                else: 
                    alpha=1-(theta/self.th3db)**2

                rho=np.sqrt((resolution*(j+0.5)-self.y*100)**2+(resolution*(k+0.5)-self.x*100)**2)        
                deltarho=1-0.5*(1+tanh(2*(rho-self.rov)))


                if rho<(r-2*self.deltark):
                    p=0.5+(self.pE-0.5)*alpha*deltarho
                elif rho>(r-2*self.deltark) and rho<(r-self.deltark):
                    p=0.5+(self.pE-0.5)*alpha*deltarho*(1-(2+(rho-r)/self.deltark)**2)
                elif rho>(r-self.deltark) and rho<(r+self.deltark):
                    p=0.5+(self.pO-0.5)*alpha*deltarho*(1-(rho-r)**2/self.deltark**2)
                else:
                    p=0.5
                self.out_matrix[j][k]=self.out_matrix[j][k]+np.log(p/(1-p))
        return 


    def run(self):
        self.sub= rospy.Subscriber('/robot0/sonar_0',Range, self.sonar0_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_1',Range, self.sonar1_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_2',Range, self.sonar2_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_3',Range, self.sonar3_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_4',Range, self.sonar4_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_5',Range, self.sonar5_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_6',Range, self.sonar6_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_7',Range, self.sonar7_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_8',Range, self.sonar8_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_9',Range, self.sonar9_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_10',Range, self.sonar10_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_11',Range, self.sonar11_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_12',Range, self.sonar12_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_13',Range, self.sonar13_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_14',Range, self.sonar14_callback)
        self.sub= rospy.Subscriber('/robot0/sonar_15',Range, self.sonar15_callback)
        self.sub= rospy.Subscriber('/robot0/odom',Odometry, self.odometry_callback)
        r=rospy.Rate(30)
        try:
            while not rospy.is_shutdown():
                self.do_mapping()
                r.sleep()
        except rospy.ROSInterruptException:                        
            pass                                            


if __name__ == '__main__':         
    mapping = map_class()                                                             
    try:
        mapping.run()
    except rospy.ROSInterruptException:
        pass
