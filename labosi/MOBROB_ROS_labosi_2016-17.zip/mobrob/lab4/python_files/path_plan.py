#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist, Pose, PoseArray
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan, sin, cos, e
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
from pprint import pprint as pp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tf
from PIL import Image
from Astar_lib import *

map_width=1500
map_height=1500
resolution=10


class plan_class():
    def __init__(self):
        rospy.init_node('plan_node')
        self.roll=0
        self.pitch=0
        self.yaw=0
        self.goal_positions=[]
        self.x=0
        self.y=0
        self.kb=0
        self.brzina=Twist()
        self.length_x=map_width/resolution
        self.length_y=map_height/resolution
        self.working_matrix=np.load('third_lab_matrix.npy')
        self.help=self.working_matrix.copy()
        for i in range(150):
            for j in range(150):
                self.working_matrix[i][j]=self.help[j][i]

    def odometry_callback(self, scan):
        quaternion = (
            scan.pose.pose.orientation.x,
            scan.pose.pose.orientation.y,
            scan.pose.pose.orientation.z,
            scan.pose.pose.orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        self.roll = euler[0]
        self.pitch = euler[1]
        self.yaw = euler[2]
        self.x=scan.pose.pose.position.x*100
        self.y=scan.pose.pose.position.y*100
        self.kb=scan.twist.twist.angular.z

    def regulator(self):
        xg, yg, x, y, tg, t = self.goal_positions[0].position.x, self.goal_positions[0].position.y, self.x, self.y, self.goal_positions[0].orientation.z, self.yaw
        xe, ye = self.goal_positions[-1].position.x, self.goal_positions[-1].position.y
        ref=atan2(yg-y, xg-x)
        e=atan2(sin(tg-t),cos(tg-t))
        K=0.5
        vlim=0.15
        vzlim=0.5
        brzina= Twist()
        print np.sqrt((xe-xg)**2+(ye-yg)**2)
        if np.sqrt((xe-xg)**2+(ye-yg)**2)>=1:
            brzina.angular.z=K*e 
            if brzina.angular.z**2>vzlim**2:
                brzina.angular.z=brzina.angular.z/abs(brzina.angular.z)*vzlim
            brzina.angular.z=brzina.angular.z
         
            if brzina.angular.z>0.02:         
                brzina.linear.x=0#vlim*(1.4-tanh(abs(10*self.kb)))
            else:
                brzina.linear.x=vlim
            if brzina.linear.x>vlim:
                brzina.linear.x=vlim

        self.brzina=brzina




    def goal_callback(self, scan): 
        self.goal_positions=scan.poses
        
    def do_planning(self):
        if self.goal_positions:
            #print self.goal_positions[0]
            self.regulator()
            

    def run(self):
        self.sub= rospy.Subscriber('/robot0/odom', Odometry, self.odometry_callback)
        self.sub= rospy.Subscriber('/robot0/goals', PoseArray, self.goal_callback)
        pub = rospy.Publisher('/robot0/cmd_vel', Twist, queue_size=10)
        r=rospy.Rate(30)
        try:
            while not rospy.is_shutdown():
                self.do_planning()
                pub.publish(self.brzina)
                r.sleep()
        except rospy.ROSInterruptException:                        
            pass                                            


if __name__ == '__main__':         
    plan = plan_class()                                                             
    try:
        plan.run()
    except rospy.ROSInterruptException:
        pass
