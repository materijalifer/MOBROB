#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist, Pose, PoseArray
from std_msgs.msg import Empty
from sensor_msgs.msg import Range
from math import atan2, pi, asin, tanh, atan, sin, cos, e, ceil
from std_msgs.msg import Int64, String, Float64, Float64MultiArray
import numpy as np
from nav_msgs.msg import Odometry
from pprint import pprint as pp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tf
from PIL import Image
from Astar_lib import *

map_width=1500
map_height=1500
resolution=10


class goal_class():
    def __init__(self):
        rospy.init_node('goal_node')
        self.working_matrix=np.load('third_lab_matrix.npy')
        self.help=self.working_matrix.copy()
        self.roll=0
        self.pitch=0
        self.yaw=0
        self.x=0
        self.y=0
        self.x_goal=0
        self.y_goal=0
        for i in range(150):
            for j in range(150):
                self.working_matrix[i][j]=self.help[j][i]
        self.robot_goal=Pose()


    def odometry_callback(self, scan):
        quaternion = (
            scan.pose.pose.orientation.x,
            scan.pose.pose.orientation.y,
            scan.pose.pose.orientation.z,
            scan.pose.pose.orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        self.roll = euler[0]
        self.pitch = euler[1]
        self.yaw = euler[2]
        self.x=scan.pose.pose.position.x*100
        self.y=scan.pose.pose.position.y*100

    def run(self):
        pub = rospy.Publisher('/robot0/goals', PoseArray, queue_size=10)
        self.sub= rospy.Subscriber('/robot0/odom', Odometry, self.odometry_callback)
        r=rospy.Rate(30)
        help_matrix=self.working_matrix.copy()
        for i in range(150):
            for j in range(150):
                if help_matrix[i][j]:
                    help_matrix[i][j]=1
        try:
            while not rospy.is_shutdown():
                tmp_list= [100, 100]
                self.robot_goal.position.x=tmp_list[0]
                self.robot_goal.position.y=tmp_list[1]

                if self.working_matrix[int(ceil(self.robot_goal.position.x/10))][int(ceil(self.robot_goal.position.y/10))]==0:
                    x1=int(ceil(self.x/10))
                    y1=int(ceil(self.y/10))
                    x2=int(ceil(self.robot_goal.position.x/10))
                    y2=int(ceil(self.robot_goal.position.y/10))
                    print x1, y1, x2, y2
                    path=astar(help_matrix, (x2,y2), (x1,y1))
                    position_data=[]
                    interesting_points=[]
                    counter=0
                    if path:
                        for i in range(1, len(path)):
                            x=path[i][0]
                            y=path[i][1]
                            theta=atan2(path[i][1]-path[i-1][1], path[i][0]-path[i-1][0])
                            tmp_pose=Pose()
                            tmp_pose.position.x=x
                            tmp_pose.position.y=y
                            tmp_pose.orientation.z=theta
                            #if position_data and abs(theta-position_data[-1][2])%pi!=0:
                            #    interesting_points.append(tmp_pose) 
                            position_data.append(tmp_pose)
                            dmy=PoseArray()
                            dmy.poses=position_data
                            pub.publish(dmy)
                else:
                    print "Invalid goal - Occupied field"

                r.sleep()
        except rospy.ROSInterruptException:                        
            pass                                            


if __name__ == '__main__':         
    goal = goal_class()                                                             
    try:
        goal.run()
    except rospy.ROSInterruptException:
        pass
