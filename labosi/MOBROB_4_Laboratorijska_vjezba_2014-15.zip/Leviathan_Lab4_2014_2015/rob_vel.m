function v12 = rob_vel(vpath2, pos_mjer, th_mjer)
    k1 = 0.9949;
    k2 = 1.0051;
    k3 = 0.9946;
	test = 3; %3 za primjenu ogranicenja
	gridcellB = 2;	

			
		
		
			[x_ y_]=g2l(vpath2(1,1),vpath2(1,2),...
				matRot(deg2rad(th_mjer)),...
				matTransl(pos_mjer(1),pos_mjer(2)));

			[th, r]=cart2pol(x_, y_);
			
			
			
			if(abs(th)<0.005)			
				th=th*k3;
				if(r>5*gridcellB)
					v12 = [15e-1/test*k2 15e-1/test*k1];
				else
					v12 = [9e-1/test*k2 9e-1/test*k1];
				end
			else
				v12 = [(-th*6e-1/test + 3e-1/test)*k2 (th*6e-1/test+3e-1/test)*k1];  
			end
			
			if(r<gridcellB)
				v12 = [1e-1 1e-1];
			end
		
