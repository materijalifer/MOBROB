function R = matRot(fi)
R = [cos(fi) sin(fi) 0; -sin(fi) cos(fi) 0;0 0 1];