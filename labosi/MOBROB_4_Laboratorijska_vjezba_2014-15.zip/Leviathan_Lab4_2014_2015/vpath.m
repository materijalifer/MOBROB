        function path_=vpath(obj, exp)
            if(isnan(obj))
                path_ = NaN;
                return;
            end
			
			str = load('mapa.mat');
            karta=str.pC;
			pc = prosiri_kartu(karta, exp);
	
            poc=1;
            kraj=2;
            index=[];
            while(kraj<=size(obj,1))
				%uzmi susjedne tocke
				%pronadi x2-x1 i y2-y1
                dd = (obj(kraj,:)*2-1)-(obj(poc,:)*2-1);
				
				%pomocu susjeda razvij prikaz u polarnim koordinatama
				%potom ispuni polarne koordinate linearnim prostorom
				%duljine r_max, podijeljenim na r_max/2 djelova
				%vrati skup tocaka u kartezijev k.s.
                [th, r_max] = cart2pol(dd(1),dd(2));
                r = linspace(0,r_max,ceil(r_max/2))';
                [x_ y_] = pol2cart(th*ones(size(r)),r);
				
				%vrati rezultat u koordinate mape
                x_ = x_+obj(poc,1)*2-1;
                y_ = y_+obj(poc,2)*2-1;
                xcell = ceil(x_/2); 
				ycell=ceil(y_/2);
				
                flag = 1;
				
				
				%iteriraj po celijama i provjeri dali
				%se putem udari u zid
                for i=1:size(r,1)
					if(pc(round(ycell(i)/2),round(xcell(i)/2))>0.5)
						flag = 0;
						break;
                    end
                end
				
				%ako nije, dodaj u listu sve osim zadnje tocke
                if(flag)
                    kraj = kraj+1;
                    if(kraj>size(obj,1))
                        index=[index;(poc+1:kraj-2)'];
                        break;
                    end
					
				%u suprotnom dodaj u listu
				%sve do tocke prije udarca u zid
                else
                    index=[index;(poc+1:kraj-2)'];
                    if(kraj==poc+1)
                        poc = kraj;
                        kraj = poc+1;
                    else
                        poc = kraj-1;
                        kraj = poc+1;
                    end
                end
            end
            tmp = obj;
			
			%obrisi indeksirane redove
			%time ostaju samo krajnje tocke do zida ili
			%do dometa r_max u tom koraku
            tmp(index,:)=[];
            path_=tmp;
        end