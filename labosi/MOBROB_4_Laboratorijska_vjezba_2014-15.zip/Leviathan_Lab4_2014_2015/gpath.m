        function path_ = gpath(obj, goal, start)
            path_ = goal;
            tmp = goal;

			path_ = [path_; obj];
            % dodamo još i start
            path_=[path_;start];
            % zarotiramo sve tako da start bude na poèetku polja
            path_=rot90(path_,2);
            % zamijenimo koordinate kako bi se pravilno crtale na karti
			%display(path_);
			%path_ = path_;
			%display(path_);
            path_=[path_(2:end-1,2) path_(2:end-1,1)];
			
        end