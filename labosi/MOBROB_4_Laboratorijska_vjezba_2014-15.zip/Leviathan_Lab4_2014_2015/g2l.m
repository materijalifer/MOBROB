function [x,y] = g2l(u,v,R,T)
tmp = [u v ones(length(u),1)]*inv(T)*inv(R);
x = tmp(:,1); y = tmp(:,2);

