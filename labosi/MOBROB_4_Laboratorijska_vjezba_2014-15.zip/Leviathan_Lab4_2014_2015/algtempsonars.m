function [new] = algtempsonars(simrobot,matrix,step)

global k1 k2 k3


persistent x_start y_start theta_start x y theta x_true y_true theta_true sensorPosition sensorAxis map pC stupac_s redak_s
persistent current_state next_state path vpath2

% define persistent variables if needed
% persistent

% set algorithm constants for laboratory excersize
gridcellB = 2;
axisLenght = 6;
gridcell = 1;
timeStep = 1;

goal = round([160 170]./gridcellB); 
% set algorithm initial parameter values
if step == 1
	
    % set calibration parameters - experiment value is 1
    k1 = 0.9949;
    k2 = 1.0051;
    k3 = 0.9946;
    
    % get estimated mobile robot start pose
    position = getestimpos(simrobot);
    theta = getestimhead(simrobot);
    x = position(1);
    y = position(2);
    
    % indeksi pocetne pozicije u karti
    stupac_s=ceil(x/gridcellB);
    redak_s=ceil(y/gridcellB);
        
    % set variables for laboratory excersize 4
    start = [stupac_s redak_s];          %start cine indeksi pocetne pozicije
                         %primjer zadanog cilja
    
    % velicina polja je ista kao za drugu vjezbu
    % before calling Astar you should write prosiri_kartu function that
    % is called inside the Astar
    pathx = Astar(start,goal);   % put izracunat A* algoritmom te prebacen u realne koordinate
	
	path = pathx * gridcellB;
	
    hold on
    figure(1)                           % crta po upravljackom prozoru simulatora
    hold on

	
	
	path2 = col(path, 3);
	display(path2);
    vpath2 = vpath(path2,2);
	display(vpath2);
	vpath2 = gpath (vpath2, goal, start);
	%display(vpath2);
	
	plot(path(:,1),path(:,2),'LineWidth',2);          %paziti na prebacivanje stupaca i redaka u x i y
	plot(vpath2(:,1),vpath2(:,2), 'r','LineWidth',2);  
    disp('Initial parameters set.');

%TESTRUN, sreden graf, malo glupo ali radi
    str = load('mapa.mat');
    karta=str.pC;	
	dimenzije = 3;
    karta = prosiri_kartu(karta, dimenzije);
	
	xcell=[1:1:100];
	ycell=xcell;
	figure(5)
	pcolor(xcell,ycell,ones(100)-karta);
	hold on, grid on
	colormap('bone');
	plot(pathx(:,1),pathx(:,2),'r','LineWidth',2); 
	plot(vpath2(:,1)/gridcellB, vpath2(:,2)/gridcellB,'b','LineWidth',1.5)
	
	[m,n] = size(vpath2);
	
	for i=1:m;
		plot(vpath2(i,1)/gridcellB,vpath2(i,2)/gridcellB,'gx',...
						'LineWidth',2,'MarkerSize',10)
	end
	

	%Do ovdje je testrun
	
	
	if(~isempty(vpath2))
        vpath2(1,:) = [];
	else
		vpath2 = goal;
    end

    
end

% get true mobile robot pose
    position = getpos(simrobot);
    x_true(step) = position(1);
    y_true(step) = position(2);
    theta_true(step) = gethead(simrobot);
    if(theta_true(step)>180)
        theta_true(step)=theta_true(step)-360;
    elseif(theta_true(step)<-180)
        theta_true(step)=theta_true(step)+360;
    end	
	
% algorithm start

	if(~isempty(vpath2))	
	
        th_mjer = getestimhead(simrobot);
        pos_mjer = getestimpos(simrobot);
		v12 = rob_vel(vpath2, pos_mjer, th_mjer);
	
		
		simrobot = setvel(simrobot, [v12(1,1) v12(1,2)]);
		
		
		

		if(v12(1,1)==1e-1 && v12(1,2)==1e-1)
            if(~isempty(vpath2))
				vpath2(1,:) = [];

			end
				
		end
	
		
		
	
	else
	
		simrobot = setvel(simrobot, [0 0]);  
		save lab4rez.mat x_true y_true theta_true path vpath2
		
		
	end	

% algorithm end

% continue simulation
new = simrobot;
