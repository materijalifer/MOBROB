function karta_=prosiri_kartu(karta_,exp)
   	[dimX,dimY]=size(karta_);
	
    for i=1:dimX
        for j=1:dimY
            if(karta_(i,j)<0.5)
                karta_(i,j)=0;
            else
                karta_(i,j)=1;
            end
        end
    end
	
	
	pc = zeros(dimX,dimY); 
	for i=1:dimX 
        for j=1:dimY 
            if karta_(i,j) == 1  
                for m=1:2*exp+1
                    for n=1:2*exp+1
                        if (i-exp-1+m)>0 && (i-exp-1+m)<=dimX && (j-exp-1+n)>0 && (j-exp-1+n)<=dimY 
                            pc(i-exp-1+m, j-exp-1+n)=1; 
                        end
                    end
                end
            end
        end
	end
	karta_ = pc;
end