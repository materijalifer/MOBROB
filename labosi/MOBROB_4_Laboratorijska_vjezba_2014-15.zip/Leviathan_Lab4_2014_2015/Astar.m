function put=Astar(start,goal)

global stablo

if ~exist('mapa.mat','file')
    error('A map for loading is needed! Copy the .mat file with the map you obtained from the second laboratory exercise!')
else
%    load mapa;
        str = load('mapa.mat');
        karta=str.pC;
end

if ~exist('prosiri_kartu', 'file')
    error('Must define function prosiri_kartu that will inflate obstacles!')
else
	dimenzije = 3;
    karta = prosiri_kartu(karta, dimenzije); % definirajte funkciju za prosirivanje prepreka
end

[sizex sizey] = size(karta);


stablo = zeros(sizex,sizey,5);
stablo(:,:,1) = karta;
stablo(:,:,4) = 'N';

xcell=[1:1:100];
ycell=xcell;
figure(2)
pcolor(xcell,ycell,ones(100)-karta);
hold on
colormap('bone');

%[r c] = find(karta==1);
%plot(c,r,'*')

put = search_path(start, goal);
%display(put);
plot(put(:,1),put(:,2),'r','LineWidth',2); 

%put=[put(:,2) put(:,1)];    %okretanje redak stupac u stupac redak da bi odgovaralo kasnije koordinatama x y