        function path_=col(obj,threshold)
            if(nargin<2)
                threshold = 1e-4;
            end
			
            if(isnan(obj))
                path_ = NaN;
                return;
            end
            warning off
            poc = 1;
            kraj = 2;
            index=[];
            while(kraj<size(obj,1))
				
				%pronadi funkciju  koja opisuje prolazak kroz 2 tocke
				%polinom stupnja 1
                params = polyfit(obj(poc:kraj,1),...
                                 obj(poc:kraj,2),1);
				
				%provjeri jeli norma funkcije kroz 2 tocke
				%i funkcije kroz 2+1 tocku slicna (manja od praga)
				%Ako je, tocke su na slicnoj funkciji
				%iteriraj dok ih ima
                while(norm(params-polyfit(obj(poc:kraj+1,1),...
                           obj(poc:kraj+1,2),1))<threshold ...
                           || obj(poc,1)==obj(kraj+1,1))
                    kraj = kraj+1;
                    if(kraj==size(obj,1)) break; end
                    params = polyfit(obj(poc:kraj,1),...
                                     obj(poc:kraj,2),1);
                end
				
				%napuni indeks sa svime izmedu glave i repa
                index=[index;(poc+1:kraj-1)'];
                poc = kraj;
                kraj = poc+1;
            end
            tmp = obj;
			
			%obriši sve s liste, time ostaju samo početne i krajnje točke
            tmp(index,:)=[];
            path_=tmp;
            warning on
        end