function T = matTransl(dx,dy)
T = [1 0 0;0 1 0;dx dy 1]; 